from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from sqlalchemy import func, and_
from typing import List, Dict, Tuple
from app.database import get_db

from app.models.hashtag import Hashtag
from app.models.hashtag_mapping import (
    CafeHashtagMap, HotelHashtagMap, RestaurantHashtagMap, TourHashtagMap
)
from app.models.jeju_cafe import JejuCafe
from app.models.jeju_hotel import JejuHotel
from app.models.jeju_restaurant import JejuRestaurant
from app.models.jeju_tour import JejuTour

from app.schemas.maps import (
    HashtageIn, HashtageOut, HashtagOnly,
    SelectHashtageIn, SelectHashtageOut, SelectHashtageOutItem
)
from ._utils import to_float, cos_sim, avg_vec

router = APIRouter(prefix="/api/users/maps", tags=["maps"])

# division → (PlaceModel, map_table, fk_field)
JOIN_INFO = {
    "cafe":       (JejuCafe, CafeHashtagMap,  CafeHashtagMap.cafe_id,       JejuCafe.x_cord, JejuCafe.y_cord),
    "hotel":      (JejuHotel, HotelHashtagMap, HotelHashtagMap.hotel_id,    JejuHotel.x_cord, JejuHotel.y_cord),
    "restaurant": (JejuRestaurant, RestaurantHashtagMap, RestaurantHashtagMap.restaurant_id, JejuRestaurant.x_cord, JejuRestaurant.y_cord),
    "tour":       (JejuTour, TourHashtagMap,  TourHashtagMap.tour_id,       JejuTour.x_cord, JejuTour.y_cord),
}

def _viewport_filter(x_col, y_col, vp):
    return and_(
        x_col >= vp.min_x, x_col <= vp.max_x,
        y_col >= vp.min_y, y_col <= vp.max_y
    )

@router.post("/hashtage", response_model=HashtageOut)
def hashtage(req: HashtageIn, db: Session = Depends(get_db)):

    if req.category not in JOIN_INFO:
        return HashtageOut(tag=[])

    Place, Map, fk, x_c, y_c = JOIN_INFO[req.category]

    rows = (
        db.query(Hashtag.hashtag, func.count().label("cnt"))
        .join(Map, Map.hashtag_id == Hashtag.hashtag_id)
        .join(Place, fk == getattr(Place, f"{req.category}_id"))
        .filter(_viewport_filter(x_c, y_c, req.viewport))
        .group_by(Hashtag.hashtag)
        .order_by(func.count().desc())
        .limit(30)
        .all()
    )
    return HashtageOut(tag=[HashtagOnly(hashtag=h) for (h, _) in rows])

@router.post("/select_hashtage", response_model=SelectHashtageOut)
def select_hashtage(req: SelectHashtageIn, db: Session = Depends(get_db)):
    """
    선택 해시태그들의 임베딩 평균 → 후보 장소(같은 카테고리)의 해시태그 임베딩 평균과 코사인 유사도
    """
    if req.category not in JOIN_INFO or not req.tag:
        return SelectHashtageOut(select_hashtage=[])

    Place, Map, fk, x_c, y_c = JOIN_INFO[req.category]

    # 1) 선택 태그 임베딩 평균
    sel_tags = [t.hashtag for t in req.tag]
    tag_rows = db.query(Hashtag).filter(func.lower(Hashtag.hashtag).in_([t.lower() for t in sel_tags])).all()
    sel_vec = avg_vec([list(h.embeddings or []) for h in tag_rows])

    if not sel_vec:
        return SelectHashtageOut(select_hashtage=[])

    # 2) 후보 장소 추출(뷰포트 내)
    places = (
        db.query(Place)
        .filter(_viewport_filter(x_c, y_c, req.viewport))
        .limit(2000)  # 안전빵 제한
        .all()
    )

    # 3) 각 장소의 태그 임베딩 평균
    results = []
    for p in places:
        pid = getattr(p, f"{req.category}_id")
        tag_rows = (
            db.query(Hashtag.embeddings, Hashtag.hashtag)
            .join(Map, Map.hashtag_id == Hashtag.hashtag_id)
            .filter(getattr(Map, f"{req.category}_id") == pid)
            .all()
        )
        place_vec = avg_vec([list(e or []) for (e, _) in tag_rows])
        sim = cos_sim(sel_vec, place_vec) if place_vec else 0.0

        results.append(SelectHashtageOutItem(
            name=p.name,
            category=req.category,
            x_cord=to_float(p.x_cord) or 0.0,
            y_cord=to_float(p.y_cord) or 0.0,
            similarity=float(sim)
        ))

    results.sort(key=lambda x: x.similarity, reverse=True)
    return SelectHashtageOut(select_hashtage=results[:100])
